$(function(e) {
	$('#example').DataTable();
	$('#example2').DataTable();
} );
$(function(e) {
	$('.data-table-example').DataTable();
} );